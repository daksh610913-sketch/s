import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: [
    './src/pages/**/*.{ts,tsx}',
    './src/components/**/*.{ts,tsx}',
    './src/app/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: '1.5rem',
      screens: {
        '2xl': '1360px',
      },
    },
    extend: {
      colors: {
        // Neutral canvas — cool porcelain, not the warm-cream AI default.
        paper: {
          DEFAULT: '#F1F4F1',
          dim: '#E7ECE7',
        },
        // Deep bottle-glass teal — primary brand color.
        glass: {
          DEFAULT: '#0E3B39',
          50: '#E7F1EF',
          100: '#CFE3E0',
          200: '#9FC7C1',
          300: '#6FAAA1',
          400: '#3F8E82',
          500: '#1C6459',
          600: '#0E3B39',
          700: '#0B2F2D',
          800: '#082221',
          900: '#051615',
        },
        // Gilded brass — rules, dividers, small accents.
        brass: {
          DEFAULT: '#B98A3D',
          light: '#E4C583',
          dark: '#8C6626',
        },
        // Oxide-brick pigment — CTAs, one deliberate warm note.
        pigment: {
          DEFAULT: '#9C3B2A',
          light: '#F1DDD6',
          dark: '#732A1E',
        },
        ink: '#16231F',
      },
      fontFamily: {
        display: ['var(--font-fraunces)', 'ui-serif', 'serif'],
        sans: ['var(--font-inter)', 'ui-sans-serif', 'sans-serif'],
        mono: ['var(--font-space-mono)', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        label: '3px',
      },
      keyframes: {
        'pour-in': {
          '0%': { transform: 'scaleY(0)', transformOrigin: 'top' },
          '100%': { transform: 'scaleY(1)', transformOrigin: 'top' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(14px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'brush-reveal': {
          '0%': { clipPath: 'inset(0 100% 0 0)' },
          '100%': { clipPath: 'inset(0 0 0 0)' },
        },
      },
      animation: {
        'pour-in': 'pour-in 0.9s cubic-bezier(0.65, 0, 0.35, 1) forwards',
        'fade-up': 'fade-up 0.7s ease-out forwards',
        'brush-reveal': 'brush-reveal 1.1s cubic-bezier(0.65, 0, 0.35, 1) forwards',
      },
    },
  },
  plugins: [],
};

export default config;
