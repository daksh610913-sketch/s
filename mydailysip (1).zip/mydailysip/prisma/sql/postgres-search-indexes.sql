-- ==================================================================
-- MyDailySip — PostgreSQL search enhancements
-- Run this AFTER `prisma migrate deploy` (tables must already exist).
-- Invoke via: npm run db:search-indexes
-- ==================================================================

CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ------------------------------------------------------------------
-- Full text search: products
-- ------------------------------------------------------------------
ALTER TABLE "products" ADD COLUMN IF NOT EXISTS "search_vector" tsvector
  GENERATED ALWAYS AS (
    setweight(to_tsvector('english', coalesce("name", '')), 'A') ||
    setweight(to_tsvector('english', coalesce("shortDescription", '')), 'B') ||
    setweight(to_tsvector('english', coalesce("description", '')), 'C')
  ) STORED;

CREATE INDEX IF NOT EXISTS "products_search_vector_idx" ON "products" USING GIN ("search_vector");
CREATE INDEX IF NOT EXISTS "products_name_trgm_idx" ON "products" USING GIN ("name" gin_trgm_ops);

-- ------------------------------------------------------------------
-- Full text search: blog posts
-- ------------------------------------------------------------------
ALTER TABLE "blog_posts" ADD COLUMN IF NOT EXISTS "search_vector" tsvector
  GENERATED ALWAYS AS (
    setweight(to_tsvector('english', coalesce("title", '')), 'A') ||
    setweight(to_tsvector('english', coalesce("excerpt", '')), 'B') ||
    setweight(to_tsvector('english', coalesce("content", '')), 'C')
  ) STORED;

CREATE INDEX IF NOT EXISTS "blog_posts_search_vector_idx" ON "blog_posts" USING GIN ("search_vector");

-- ------------------------------------------------------------------
-- Trigram index for fuzzy search on categories
-- ------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS "categories_name_trgm_idx" ON "categories" USING GIN ("name" gin_trgm_ops);
