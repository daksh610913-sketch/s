import { PrismaClient, UserType, UserStatus, ProductType, ProductStatus, CurrencyCode, ShippingZoneType, TaxType, FeatureFlagStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// ==================================================================
// Permission catalog — module: action pairs
// ==================================================================
const PERMISSION_MODULES: Record<string, string[]> = {
  products: ['view', 'create', 'update', 'delete'],
  categories: ['view', 'create', 'update', 'delete'],
  inventory: ['view', 'update'],
  orders: ['view', 'update', 'cancel', 'refund'],
  customers: ['view', 'update', 'ban'],
  coupons: ['view', 'create', 'update', 'delete'],
  reviews: ['view', 'moderate', 'delete'],
  returns: ['view', 'approve', 'reject'],
  blogs: ['view', 'create', 'update', 'delete', 'publish'],
  media: ['view', 'upload', 'delete'],
  marketing: ['view', 'create', 'send'],
  reports: ['view', 'export'],
  website: ['view', 'edit', 'publish'],
  crm: ['view', 'manage'],
  appointments: ['view', 'manage'],
  admins: ['view', 'create', 'update', 'delete'],
  roles: ['view', 'create', 'update', 'delete'],
  api_keys: ['view', 'create', 'revoke'],
  database: ['backup', 'restore', 'view'],
  feature_flags: ['view', 'toggle'],
  audit_logs: ['view'],
  settings: ['view', 'update'],
};

async function seedPermissionsAndRoles() {
  console.log('Seeding permissions...');

  const permissionRecords: { id: string; module: string; slug: string }[] = [];

  for (const [module, actions] of Object.entries(PERMISSION_MODULES)) {
    for (const action of actions) {
      const slug = `${module}.${action}`;
      const permission = await prisma.permission.upsert({
        where: { slug },
        update: {},
        create: {
          name: `${action} ${module}`.replace(/^\w/, (c) => c.toUpperCase()),
          slug,
          module,
          description: `Allows the ${action} action on ${module}`,
        },
      });
      permissionRecords.push({ id: permission.id, module, slug });
    }
  }

  console.log(`Seeded ${permissionRecords.length} permissions.`);

  console.log('Seeding roles...');

  const superAdminRole = await prisma.role.upsert({
    where: { slug: 'super-admin' },
    update: {},
    create: {
      name: 'Super Admin',
      slug: 'super-admin',
      description: 'Full unrestricted access to every module including system configuration.',
      isSystem: true,
    },
  });

  const adminRole = await prisma.role.upsert({
    where: { slug: 'admin' },
    update: {},
    create: {
      name: 'Admin',
      slug: 'admin',
      description: 'Operational access to storefront, catalog, orders, and marketing.',
      isSystem: true,
    },
  });

  const supportRole = await prisma.role.upsert({
    where: { slug: 'support-agent' },
    update: {},
    create: {
      name: 'Support Agent',
      slug: 'support-agent',
      description: 'Handles customer tickets, chats, returns, and appointments.',
      isSystem: true,
    },
  });

  const customerRole = await prisma.role.upsert({
    where: { slug: 'customer' },
    update: {},
    create: {
      name: 'Customer',
      slug: 'customer',
      description: 'Default role for storefront customers.',
      isSystem: true,
    },
  });

  // Super admin: every permission
  for (const perm of permissionRecords) {
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: superAdminRole.id, permissionId: perm.id } },
      update: {},
      create: { roleId: superAdminRole.id, permissionId: perm.id },
    });
  }

  // Admin: everything except admins/roles/api_keys/database/feature_flags management
  const adminRestrictedModules = new Set(['admins', 'roles', 'api_keys', 'database', 'feature_flags']);
  for (const perm of permissionRecords) {
    if (adminRestrictedModules.has(perm.module)) continue;
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: adminRole.id, permissionId: perm.id } },
      update: {},
      create: { roleId: adminRole.id, permissionId: perm.id },
    });
  }

  // Support agent: limited to orders(view), customers(view), returns, appointments, crm, reviews(moderate)
  const supportAllowedSlugs = new Set([
    'orders.view',
    'customers.view',
    'returns.view',
    'returns.approve',
    'returns.reject',
    'appointments.view',
    'appointments.manage',
    'crm.view',
    'crm.manage',
    'reviews.view',
    'reviews.moderate',
  ]);
  for (const perm of permissionRecords) {
    if (!supportAllowedSlugs.has(perm.slug)) continue;
    await prisma.rolePermission.upsert({
      where: { roleId_permissionId: { roleId: supportRole.id, permissionId: perm.id } },
      update: {},
      create: { roleId: supportRole.id, permissionId: perm.id },
    });
  }

  console.log('Roles seeded: super-admin, admin, support-agent, customer.');

  return { superAdminRole, adminRole, supportRole, customerRole };
}

async function seedUsers(roles: {
  superAdminRole: { id: string };
  adminRole: { id: string };
  supportRole: { id: string };
  customerRole: { id: string };
}) {
  console.log('Seeding users...');

  const passwordHash = await bcrypt.hash('ChangeMe@123!', 12);

  const superAdmin = await prisma.user.upsert({
    where: { email: 'superadmin@mydailysip.com' },
    update: {},
    create: {
      email: 'superadmin@mydailysip.com',
      passwordHash,
      firstName: 'Root',
      lastName: 'Administrator',
      userType: UserType.SUPER_ADMIN,
      status: UserStatus.ACTIVE,
      roleId: roles.superAdminRole.id,
      emailVerifiedAt: new Date(),
    },
  });

  const admin = await prisma.user.upsert({
    where: { email: 'admin@mydailysip.com' },
    update: {},
    create: {
      email: 'admin@mydailysip.com',
      passwordHash,
      firstName: 'Store',
      lastName: 'Admin',
      userType: UserType.ADMIN,
      status: UserStatus.ACTIVE,
      roleId: roles.adminRole.id,
      emailVerifiedAt: new Date(),
    },
  });

  await prisma.user.upsert({
    where: { email: 'support@mydailysip.com' },
    update: {},
    create: {
      email: 'support@mydailysip.com',
      passwordHash,
      firstName: 'Support',
      lastName: 'Agent',
      userType: UserType.ADMIN,
      status: UserStatus.ACTIVE,
      roleId: roles.supportRole.id,
      emailVerifiedAt: new Date(),
    },
  });

  const customer = await prisma.user.upsert({
    where: { email: 'customer@example.com' },
    update: {},
    create: {
      email: 'customer@example.com',
      passwordHash,
      firstName: 'Priya',
      lastName: 'Sharma',
      userType: UserType.CUSTOMER,
      status: UserStatus.ACTIVE,
      roleId: roles.customerRole.id,
      emailVerifiedAt: new Date(),
      phone: '+919810000000',
    },
  });

  console.log('Seeded users: superadmin@mydailysip.com, admin@mydailysip.com, support@mydailysip.com, customer@example.com');
  console.log('Default password for all seeded users: ChangeMe@123!');

  return { superAdmin, admin, customer };
}

async function seedTaxAndShipping() {
  console.log('Seeding tax rates and shipping zones...');

  const gst18 = await prisma.taxRate.upsert({
    where: { id: '00000000-0000-0000-0000-000000000001' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000001',
      name: 'GST 18%',
      type: TaxType.GST,
      percentage: 18,
      country: 'India',
      isActive: true,
    },
  });

  const gst12 = await prisma.taxRate.upsert({
    where: { id: '00000000-0000-0000-0000-000000000002' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000002',
      name: 'GST 12%',
      type: TaxType.GST,
      percentage: 12,
      country: 'India',
      isActive: true,
    },
  });

  const domesticZone = await prisma.shippingZone.upsert({
    where: { id: '00000000-0000-0000-0000-000000000010' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000010',
      name: 'India',
      type: ShippingZoneType.DOMESTIC,
      countries: ['India'],
      isActive: true,
    },
  });

  await prisma.shippingMethod.upsert({
    where: { id: '00000000-0000-0000-0000-000000000020' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000020',
      zoneId: domesticZone.id,
      name: 'Standard Delivery',
      description: 'Delivered in 4-7 business days',
      price: 79,
      freeAboveAmount: 999,
      minDays: 4,
      maxDays: 7,
      isActive: true,
    },
  });

  await prisma.shippingMethod.upsert({
    where: { id: '00000000-0000-0000-0000-000000000021' },
    update: {},
    create: {
      id: '00000000-0000-0000-0000-000000000021',
      zoneId: domesticZone.id,
      name: 'Express Delivery',
      description: 'Delivered in 1-2 business days',
      price: 199,
      minDays: 1,
      maxDays: 2,
      isActive: true,
    },
  });

  return { gst18, gst12 };
}

async function seedCatalog(taxRates: { gst18: { id: string }; gst12: { id: string } }) {
  console.log('Seeding categories and products...');

  const glassCategory = await prisma.category.upsert({
    where: { slug: 'hand-painted-glass-bottles' },
    update: {},
    create: {
      name: 'Hand-Painted Glass Bottles',
      slug: 'hand-painted-glass-bottles',
      description: 'Artisan hand-painted glass water bottles crafted by skilled painters.',
      isActive: true,
      metaTitle: 'Hand-Painted Glass Water Bottles | MyDailySip',
      metaDescription: 'Shop premium hand-painted glass water bottles, each uniquely crafted by artisan painters.',
    },
  });

  const plasticCategory = await prisma.category.upsert({
    where: { slug: 'bpa-free-plastic-bottles' },
    update: {},
    create: {
      name: 'BPA-Free Plastic Bottles',
      slug: 'bpa-free-plastic-bottles',
      description: 'Lightweight, durable, and completely BPA-free plastic water bottles.',
      isActive: true,
      metaTitle: 'BPA-Free Plastic Water Bottles | MyDailySip',
      metaDescription: 'Shop safe, durable, and BPA-free plastic water bottles for daily hydration.',
    },
  });

  const giftCategory = await prisma.category.upsert({
    where: { slug: 'gift-sets' },
    update: {},
    create: {
      name: 'Gift Sets',
      slug: 'gift-sets',
      description: 'Curated bottle gift sets for every occasion.',
      isActive: true,
    },
  });

  const products = [
    {
      sku: 'MDS-GLS-001',
      name: 'Lotus Bloom Hand-Painted Glass Bottle',
      slug: 'lotus-bloom-hand-painted-glass-bottle',
      shortDescription: 'A serene lotus motif hand-painted on borosilicate glass.',
      description:
        'The Lotus Bloom bottle features a delicate lotus flower design hand-painted by our artisans using non-toxic, food-safe enamel paint. Crafted from premium borosilicate glass, it is resistant to thermal shock and free from any harmful chemicals. Each bottle is a unique piece of wearable art for your daily hydration ritual.',
      type: ProductType.GLASS_BOTTLE,
      categoryId: glassCategory.id,
      basePrice: 1299,
      compareAtPrice: 1599,
      costPrice: 650,
      material: 'Borosilicate Glass',
      capacityMl: 750,
      weightGrams: 340,
      isHandPainted: true,
      isBpaFree: true,
      taxRateId: taxRates.gst12.id,
      status: ProductStatus.PUBLISHED,
      publishedAt: new Date(),
    },
    {
      sku: 'MDS-GLS-002',
      name: 'Peacock Feather Hand-Painted Glass Bottle',
      slug: 'peacock-feather-hand-painted-glass-bottle',
      shortDescription: 'Vibrant peacock feather artwork on premium glass.',
      description:
        'Inspired by the iridescent beauty of peacock feathers, this bottle is hand-painted with vivid blues and greens by our in-house artists. Made from lead-free borosilicate glass with a protective silicone sleeve for grip and drop protection.',
      type: ProductType.GLASS_BOTTLE,
      categoryId: glassCategory.id,
      basePrice: 1399,
      compareAtPrice: 1699,
      costPrice: 700,
      material: 'Borosilicate Glass with Silicone Sleeve',
      capacityMl: 750,
      weightGrams: 400,
      isHandPainted: true,
      isBpaFree: true,
      taxRateId: taxRates.gst12.id,
      status: ProductStatus.PUBLISHED,
      publishedAt: new Date(),
    },
    {
      sku: 'MDS-PLA-001',
      name: 'Sprint BPA-Free Sports Bottle',
      slug: 'sprint-bpa-free-sports-bottle',
      shortDescription: 'Lightweight, leak-proof BPA-free sports bottle.',
      description:
        'Built for active lifestyles, the Sprint bottle is made from Tritan copolyester that is completely BPA, BPS, and phthalate free. Featuring a leak-proof flip-top cap, ergonomic grip, and a wide mouth for easy cleaning and ice cube filling.',
      type: ProductType.PLASTIC_BOTTLE,
      categoryId: plasticCategory.id,
      basePrice: 499,
      compareAtPrice: 649,
      costPrice: 180,
      material: 'Tritan Copolyester',
      capacityMl: 1000,
      weightGrams: 150,
      isHandPainted: false,
      isBpaFree: true,
      taxRateId: taxRates.gst18.id,
      status: ProductStatus.PUBLISHED,
      publishedAt: new Date(),
    },
    {
      sku: 'MDS-GFT-001',
      name: 'Artisan Duo Gift Set',
      slug: 'artisan-duo-gift-set',
      shortDescription: 'Two hand-painted glass bottles in a premium gift box.',
      description:
        'A thoughtfully curated gift set featuring two of our best-selling hand-painted glass bottles, packaged in an elegant kraft gift box with a personalized note card. Perfect for weddings, festivals, and corporate gifting.',
      type: ProductType.GIFT_SET,
      categoryId: giftCategory.id,
      basePrice: 2499,
      compareAtPrice: 2999,
      costPrice: 1300,
      material: 'Borosilicate Glass',
      capacityMl: 750,
      weightGrams: 900,
      isHandPainted: true,
      isBpaFree: true,
      taxRateId: taxRates.gst12.id,
      status: ProductStatus.PUBLISHED,
      publishedAt: new Date(),
    },
  ];

  for (const p of products) {
    const product = await prisma.product.upsert({
      where: { slug: p.slug },
      update: {},
      create: p,
    });

    await prisma.productVariant.upsert({
      where: { sku: `${p.sku}-DEF` },
      update: {},
      create: {
        productId: product.id,
        sku: `${p.sku}-DEF`,
        name: 'Default',
        price: p.basePrice,
        compareAtPrice: p.compareAtPrice,
        stockQuantity: 250,
        reorderLevel: 25,
        isDefault: true,
        isActive: true,
      },
    });

    const existingImage = await prisma.productImage.findFirst({
      where: { productId: product.id, isPrimary: true },
    });
    if (!existingImage) {
      await prisma.productImage.create({
        data: {
          productId: product.id,
          url: `https://res.cloudinary.com/mydailysip/image/upload/v1/products/${p.slug}-1.jpg`,
          altText: p.name,
          isPrimary: true,
          sortOrder: 0,
        },
      });
    }
  }

  console.log(`Seeded ${products.length} products across 3 categories.`);
}

async function seedFeatureFlags() {
  console.log('Seeding feature flags...');
  const flags = [
    { key: 'wishlist', name: 'Wishlist', status: FeatureFlagStatus.ENABLED },
    { key: 'reviews', name: 'Product Reviews', status: FeatureFlagStatus.ENABLED },
    { key: 'cod', name: 'Cash on Delivery', status: FeatureFlagStatus.ENABLED },
    { key: 'live_chat', name: 'Live Chat Support', status: FeatureFlagStatus.ENABLED },
    { key: 'referral_program', name: 'Referral Program', status: FeatureFlagStatus.DISABLED },
  ];
  for (const flag of flags) {
    await prisma.featureFlag.upsert({
      where: { key: flag.key },
      update: {},
      create: flag,
    });
  }
}

async function seedThemeSettings() {
  console.log('Seeding theme settings...');
  const settings: Record<string, unknown> = {
    'brand.primaryColor': '#2563eb',
    'brand.secondaryColor': '#0f172a',
    'brand.logoUrl': 'https://res.cloudinary.com/mydailysip/image/upload/v1/branding/logo.svg',
    'brand.faviconUrl': 'https://res.cloudinary.com/mydailysip/image/upload/v1/branding/favicon.ico',
    'storefront.currency': CurrencyCode.INR,
    'storefront.freeShippingThreshold': 999,
  };
  for (const [key, value] of Object.entries(settings)) {
    await prisma.themeSetting.upsert({
      where: { key },
      update: {},
      create: { key, value: value as any, category: key.split('.')[0] },
    });
  }
}

async function main() {
  console.log('==================================================');
  console.log('MyDailySip — Database Seed');
  console.log('==================================================');

  const roles = await seedPermissionsAndRoles();
  await seedUsers(roles);
  const taxRates = await seedTaxAndShipping();
  await seedCatalog(taxRates);
  await seedFeatureFlags();
  await seedThemeSettings();

  console.log('==================================================');
  console.log('Seed completed successfully.');
  console.log('==================================================');
}

main()
  .catch((e) => {
    console.error('Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
