# MyDailySip — Enterprise E-Commerce Platform

Premium hand-painted glass & BPA-free plastic water bottles. Full-stack platform:
customer storefront, Admin dashboard, Super Admin dashboard, real-time analytics,
CRM, marketing automation, and complete audit/security tracking.

## Tech Stack

- **Framework:** Next.js 14 (App Router) + React 18 + TypeScript
- **Styling:** Tailwind CSS
- **Database:** PostgreSQL + Prisma ORM
- **Auth:** NextAuth (credentials + OAuth) + JWT + RBAC
- **Cache/Queue:** Redis + BullMQ
- **Media:** Cloudinary
- **Payments:** Stripe + Razorpay
- **Email:** Nodemailer
- **Real-time:** Socket.IO / WebSockets
- **Infra:** Docker Compose

## Deploying for free — Vercel + Neon + Upstash

InfinityFree (shared PHP hosting) **cannot run this project** — there's no Node.js
runtime, no persistent processes, and no Postgres. The stack below actually runs the
whole app — storefront, Admin, Super Admin, REST API — at $0.

| Piece | Service | Why |
|---|---|---|
| App hosting | [Vercel](https://vercel.com) (Hobby) | Runs Next.js natively, free tier. **Vercel's Hobby ToS is non-commercial personal use** — fine while building; move to Pro ($20/mo) once you're actually taking real payments. |
| Database | [Neon](https://neon.tech) (Free) | Serverless Postgres, no credit card, 0.5GB storage / 100 compute-hours per month. Scales to zero when idle (a few hundred ms cold start — not noticeable for a store this size). |
| Cache / rate limiting | [Upstash](https://upstash.com) (Free) | Serverless Redis over REST — 500K commands/month, no card. Works natively with serverless functions (no persistent TCP connection needed). |
| Media | [Cloudinary](https://cloudinary.com) (Free) | Already used in this project — generous free tier for images. |
| Payments | Stripe / Razorpay test mode | Free while developing; switch to live keys when you launch. |

**What doesn't fit serverless hosting:** a self-hosted WebSocket server can't hold a
persistent connection open inside a Vercel function. When the real-time dashboard is
built, it'll use **Vercel Cron** (free, once-per-day on Hobby) plus a serverless push
service like Pusher or Ably (both have real free tiers) instead of a dedicated
Socket.IO process — so the entire stack stays serverless with nothing to pay for
around the clock.

### Step by step

1. **Create the database.** Sign up at neon.tech, create a project named `mydailysip`.
   Copy both connection strings from the Connection Details panel:
   - The **pooled** string → `DATABASE_URL`
   - The **direct/unpooled** string → `DIRECT_URL`

2. **Create the cache.** Sign up at upstash.com, create a Redis database, copy the
   REST URL and token into `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`.

3. **Push the schema and seed data** from your machine (one-time, before first deploy):
   ```bash
   npm install
   npm run prisma:migrate:deploy   # applies the schema to Neon
   npm run db:search-indexes       # adds full-text search indexes
   npm run prisma:seed             # roles, sample catalog, test accounts
   ```

4. **Push this project to a GitHub repo**, then in Vercel: New Project → import the
   repo → it auto-detects Next.js.

5. **Add environment variables** in the Vercel project's Settings → Environment
   Variables (copy every value from your filled-in `.env` — Vercel does **not** read
   your local `.env` file, it only reads what you paste into its dashboard).

6. **Deploy.** Vercel builds and gives you a `*.vercel.app` URL immediately; attach a
   custom domain for free under Settings → Domains.

### Local development (unchanged)

```bash
cp .env.example .env
docker compose up -d postgres redis   # local Postgres + Redis for dev only
npm install
npm run prisma:migrate
npm run db:search-indexes
npm run prisma:seed
npm run dev
```

Seeded accounts (password for all: `ChangeMe@123!`):

| Role | Email |
|---|---|
| Super Admin | superadmin@mydailysip.com |
| Admin | admin@mydailysip.com |
| Support Agent | support@mydailysip.com |
| Customer | customer@example.com |

## Project Structure

```
mydailysip/
├── prisma/
│   ├── schema.prisma          # 66 models, 43 enums — full domain model
│   ├── seed.ts                 # roles/permissions/users/catalog/tax/shipping/flags
│   └── sql/
│       └── postgres-search-indexes.sql   # tsvector + GIN full-text search (run post-migration)
├── docker/
│   └── postgres/init.sql       # extensions bootstrap (local dev only)
├── src/
│   ├── app/                    # Next.js App Router routes (storefront, admin, super-admin, api)
│   ├── components/
│   ├── lib/
│   │   ├── prisma.ts           # Prisma client singleton
│   │   └── redis.ts            # Upstash REST (prod) / ioredis (local dev) — auto-selected
│   ├── server/                 # RBAC middleware, etc.
│   ├── workers/                # BullMQ workers — for the optional self-hosted/Docker path only
│   └── types/
├── vercel.json                 # Vercel build + cron config (free-tier-safe schedules)
├── docker-compose.yml           # local dev / self-hosted alternative — not needed for Vercel deploys
├── Dockerfile
└── package.json
```

## Database Design Notes

- All primary keys are UUIDs (`@db.Uuid`, `uuid()` default).
- Every business entity has `createdAt`/`updatedAt`; soft-deletable entities also carry `deletedAt`.
- Full audit trail via `AuditLog` (system-level actions), `ActivityLog` (user activity),
  and `ImpersonationLog` (admin-as-customer sessions).
- Visitor analytics captured via `VisitorSession`, `PageView`, `ClickEvent`, `SearchLog`,
  and rolled up daily into `TrafficDailyStat`.
- RBAC is fully data-driven: `Role` → `RolePermission` → `Permission`, seeded with
  four system roles (`super-admin`, `admin`, `support-agent`, `customer`).
- Postgres full-text search uses generated `tsvector` columns + GIN indexes, applied via
  `prisma/sql/postgres-search-indexes.sql` (Prisma's `@@fulltext` attribute is MySQL-only,
  so this is handled as a raw SQL step run after `prisma migrate deploy`).

## Build Status

This is being built incrementally, file by file, in production-quality form (no
pseudocode/placeholders). Given the true scope of this system, it is being delivered
across multiple turns. See conversation for current progress; reply "Continue" to
resume the next module.

### Completed
- [x] Project scaffolding (package.json, tsconfig, next.config, tailwind.config)
- [x] Docker Compose + Dockerfile (multi-stage)
- [x] Environment variable template (`.env.example`)
- [x] Complete Prisma schema (66 models / 43 enums) — identity/RBAC, catalog,
      cart/wishlist, orders/payments/coupons, reviews/returns, blog/CRM,
      notifications/marketing/chat/media/website-builder, audit/analytics/backup
- [x] Prisma client singleton
- [x] Database seed script

### Next up
- [ ] NextAuth configuration + JWT/session strategy + RBAC middleware
- [ ] Core lib utilities (validation schemas, API response helpers, rate limiting)
- [ ] REST API routes (catalog, cart, checkout, orders)
- [ ] Stripe + Razorpay payment integration
- [ ] Customer storefront UI
- [ ] Admin dashboard UI
- [ ] Super Admin dashboard UI
- [ ] WebSocket real-time server (live orders/visitors/notifications)
- [ ] Background workers (email, notifications)
- [ ] API documentation
