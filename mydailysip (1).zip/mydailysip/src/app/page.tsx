import Link from 'next/link';
import { BottleIllustration } from '@/components/bottle-illustration';
import { ProductCard, type ProductCardData } from '@/components/product-card';
import { getFeaturedProducts, getStorefrontCategories } from '@/lib/products';

export const revalidate = 300;

export default async function HomePage() {
  const [featuredProducts, categories] = await Promise.all([
    safeFetch(() => getFeaturedProducts(8), [] as ProductCardData[]),
    safeFetch(() => getStorefrontCategories(), [] as Awaited<ReturnType<typeof getStorefrontCategories>>),
  ]);

  return (
    <>
      {/* ============================================================ */}
      {/* HERO                                                         */}
      {/* ============================================================ */}
      <section className="relative overflow-hidden bg-glass text-paper">
        <div className="container grid gap-12 py-20 lg:grid-cols-2 lg:items-center lg:py-28">
          <div className="animate-fade-up">
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-brass-light">
              Hand-painted &middot; BPA-free &middot; Made to be refilled
            </span>
            <h1 className="mt-5 max-w-lg font-display text-5xl font-medium leading-[1.05] tracking-tight sm:text-6xl">
              Water, worn <span className="italic text-brass-light">like art.</span>
            </h1>
            <p className="mt-6 max-w-md text-paper/75">
              Every glass bottle in our studio is painted by hand — no two alike. Every
              plastic bottle is built BPA-free, for the days you need something lighter.
              Either way, it&apos;s made for daily use, not a display shelf.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Link
                href="/shop/glass"
                className="rounded-label bg-pigment px-6 py-3 text-sm font-medium text-paper transition-colors hover:bg-pigment-dark"
              >
                Shop hand-painted glass
              </Link>
              <Link
                href="/shop/plastic"
                className="rounded-label border border-paper/40 px-6 py-3 text-sm font-medium text-paper transition-colors hover:border-paper hover:bg-paper/10"
              >
                Shop BPA-free plastic
              </Link>
            </div>
          </div>

          <div className="relative mx-auto flex h-[420px] w-full max-w-sm items-end justify-center">
            <div
              className="absolute inset-0 origin-top animate-pour-in rounded-full bg-brass/10 blur-3xl"
              aria-hidden="true"
            />
            <BottleIllustration
              variant="lotus"
              className="relative h-full w-auto drop-shadow-[0_30px_40px_rgba(0,0,0,0.35)]"
            />
          </div>
        </div>
      </section>

      {/* ============================================================ */}
      {/* TWO WAYS TO SIP                                               */}
      {/* ============================================================ */}
      <section className="container py-20">
        <div className="label-ribbon">
          <span className="font-mono text-xs uppercase tracking-[0.2em]">Two ways to sip</span>
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2">
          <Link
            href="/shop/glass"
            className="group relative flex flex-col justify-between overflow-hidden rounded-label border border-brass/30 bg-pigment-light p-8 transition-shadow hover:shadow-xl"
          >
            <div>
              <h2 className="font-display text-3xl text-glass-900">Hand-Painted Glass</h2>
              <p className="mt-3 max-w-xs text-sm text-ink/70">
                Borosilicate glass, painted stroke by stroke by our studio artists. Each
                bottle carries a small signature on the base.
              </p>
            </div>
            <span className="mt-8 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wide text-pigment group-hover:gap-3">
              Explore the collection →
            </span>
          </Link>

          <Link
            href="/shop/plastic"
            className="group relative flex flex-col justify-between overflow-hidden rounded-label border border-glass/20 bg-glass-50 p-8 transition-shadow hover:shadow-xl"
          >
            <div>
              <h2 className="font-display text-3xl text-glass-900">BPA-Free Plastic</h2>
              <p className="mt-3 max-w-xs text-sm text-ink/70">
                Tritan copolyester, leak-proof caps, and a wide mouth for easy cleaning.
                Built for gym bags and school runs.
              </p>
            </div>
            <span className="mt-8 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wide text-glass group-hover:gap-3">
              Explore the collection →
            </span>
          </Link>
        </div>

        {categories.length > 0 ? (
          <div className="mt-4 flex flex-wrap gap-3 pt-6">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                href={`/shop/${cat.slug}`}
                className="rounded-label border border-glass-100 px-4 py-2 text-xs text-ink/70 hover:border-glass hover:text-glass"
              >
                {cat.name} ({cat.productCount})
              </Link>
            ))}
          </div>
        ) : null}
      </section>

      {/* ============================================================ */}
      {/* FEATURED PRODUCTS                                             */}
      {/* ============================================================ */}
      <section className="bg-paper-dim py-20">
        <div className="container">
          <div className="label-ribbon">
            <span className="font-mono text-xs uppercase tracking-[0.2em]">
              This week&apos;s favourites
            </span>
          </div>

          {featuredProducts.length > 0 ? (
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {featuredProducts.map((product) => (
                <ProductCard key={product.slug} product={product} />
              ))}
            </div>
          ) : (
            <div className="mt-10 rounded-label border border-dashed border-glass-100 bg-white p-12 text-center">
              <p className="text-ink/60">
                Nothing to show here yet — publish a product in the Admin dashboard and
                it will appear on this shelf automatically.
              </p>
            </div>
          )}
        </div>
      </section>

      {/* ============================================================ */}
      {/* CRAFT STORY                                                   */}
      {/* ============================================================ */}
      <section className="container py-20">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <div className="flex justify-center">
            <BottleIllustration variant="peacock" className="h-96 w-auto" />
          </div>
          <div>
            <div className="label-ribbon">
              <span className="font-mono text-xs uppercase tracking-[0.2em]">Our craft</span>
            </div>
            <h2 className="mt-6 max-w-md font-display text-4xl leading-tight text-ink">
              Every stroke is laid down by a real hand, not a print head.
            </h2>
            <p className="mt-5 max-w-md text-ink/70">
              Our studio works with a small group of artists trained in traditional glass
              painting. A single bottle can take up to 40 minutes to paint and cure — which
              is also why no two are ever perfectly identical.
            </p>
            <Link
              href="/our-craft"
              className="mt-6 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wide text-pigment"
            >
              Read about our process →
            </Link>
          </div>
        </div>
      </section>

      {/* ============================================================ */}
      {/* GIFTING BANNER                                                */}
      {/* ============================================================ */}
      <section className="bg-glass-900 py-16 text-paper">
        <div className="container flex flex-col items-center gap-6 text-center">
          <div className="label-ribbon">
            <span className="font-mono text-xs uppercase tracking-[0.2em]">
              Gifting, made personal
            </span>
          </div>
          <h2 className="max-w-xl font-display text-3xl">
            Corporate gifting and wedding favours, painted to order.
          </h2>
          <p className="max-w-lg text-paper/70">
            Bulk orders of 25 or more can include a custom motif, engraved name, or
            company mark. Book a short consultation and we&apos;ll send a proof within 48
            hours.
          </p>
          <Link
            href="/appointments"
            className="rounded-label bg-brass px-6 py-3 text-sm font-medium text-glass-900 hover:bg-brass-light"
          >
            Book a consultation
          </Link>
        </div>
      </section>
    </>
  );
}

async function safeFetch<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    console.error('Storefront data fetch failed, using empty fallback:', error);
    return fallback;
  }
}
