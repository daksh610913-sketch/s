import Link from 'next/link';

const FOOTER_COLUMNS = [
  {
    title: 'Shop',
    links: [
      { href: '/shop/glass', label: 'Hand-Painted Glass' },
      { href: '/shop/plastic', label: 'BPA-Free Plastic' },
      { href: '/shop/gift-sets', label: 'Gift Sets' },
      { href: '/shop/bestsellers', label: 'Bestsellers' },
    ],
  },
  {
    title: 'Support',
    links: [
      { href: '/contact', label: 'Contact Us' },
      { href: '/returns', label: 'Returns & Refunds' },
      { href: '/appointments', label: 'Book a Consultation' },
      { href: '/faq', label: 'FAQ' },
    ],
  },
  {
    title: 'Company',
    links: [
      { href: '/our-craft', label: 'Our Craft' },
      { href: '/blog', label: 'Journal' },
      { href: '/corporate-gifting', label: 'Corporate Gifting' },
      { href: '/careers', label: 'Careers' },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="bg-glass text-paper">
      <div className="container grid gap-12 py-16 lg:grid-cols-[1.2fr_1fr_1fr_1fr]">
        <div>
          <span className="font-display text-2xl font-medium">MyDailySip</span>
          <p className="mt-4 max-w-xs text-sm text-paper/70">
            Every glass bottle is painted by hand, one stroke at a time. Every plastic
            bottle is built to carry water safely, every day.
          </p>
          <form className="mt-6 flex max-w-xs gap-2">
            <label htmlFor="footer-email" className="sr-only">
              Email address
            </label>
            <input
              id="footer-email"
              type="email"
              required
              placeholder="you@email.com"
              className="w-full rounded-label border border-paper/30 bg-transparent px-3 py-2 text-sm text-paper placeholder:text-paper/40 focus:border-brass"
            />
            <button
              type="submit"
              className="whitespace-nowrap rounded-label bg-brass px-4 py-2 text-sm font-medium text-glass-900 transition-colors hover:bg-brass-light"
            >
              Join
            </button>
          </form>
        </div>

        {FOOTER_COLUMNS.map((col) => (
          <div key={col.title}>
            <h3 className="font-mono text-xs uppercase tracking-[0.15em] text-brass-light">
              {col.title}
            </h3>
            <ul className="mt-4 space-y-3">
              {col.links.map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-sm text-paper/75 hover:text-paper">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-paper/10">
        <div className="container flex flex-col gap-2 py-6 text-xs text-paper/50 sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} MyDailySip. All rights reserved.</p>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover:text-paper/80">
              Privacy Policy
            </Link>
            <Link href="/terms" className="hover:text-paper/80">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
