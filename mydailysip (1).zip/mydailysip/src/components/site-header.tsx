import Link from 'next/link';

const NAV_LINKS = [
  { href: '/shop/glass', label: 'Hand-Painted Glass' },
  { href: '/shop/plastic', label: 'BPA-Free Plastic' },
  { href: '/shop/gift-sets', label: 'Gift Sets' },
  { href: '/our-craft', label: 'Our Craft' },
  { href: '/blog', label: 'Journal' },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-brass/30 bg-paper/95 backdrop-blur">
      <div className="container flex h-20 items-center justify-between">
        <Link href="/" className="group flex items-baseline gap-2">
          <span className="font-display text-2xl font-medium tracking-tight text-glass">
            MyDailySip
          </span>
          <span className="hidden font-mono text-[10px] uppercase tracking-[0.2em] text-brass-dark sm:inline">
            est. hand-poured
          </span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex" aria-label="Primary">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm text-ink/80 transition-colors hover:text-pigment"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-5">
          <Link
            href="/account"
            className="hidden text-sm text-ink/80 transition-colors hover:text-pigment sm:inline"
          >
            Account
          </Link>
          <Link
            href="/cart"
            className="relative inline-flex items-center gap-2 rounded-label border border-glass px-4 py-2 text-sm font-medium text-glass transition-colors hover:bg-glass hover:text-paper"
          >
            Cart
            <span className="font-mono text-xs" aria-hidden="true">
              (0)
            </span>
          </Link>
        </div>
      </div>
    </header>
  );
}
