type BottleVariant = 'lotus' | 'peacock' | 'sport' | 'giftset';

const PALETTES: Record<BottleVariant, { wash: string; accent: string; accent2: string }> = {
  lotus: { wash: '#F1DDD6', accent: '#9C3B2A', accent2: '#B98A3D' },
  peacock: { wash: '#CFE3E0', accent: '#0E3B39', accent2: '#3F8E82' },
  sport: { wash: '#E7ECE7', accent: '#1C6459', accent2: '#0E3B39' },
  giftset: { wash: '#E4C583', accent: '#8C6626', accent2: '#9C3B2A' },
};

export function BottleIllustration({
  variant,
  className,
}: {
  variant: BottleVariant;
  className?: string;
}) {
  const p = PALETTES[variant];

  return (
    <svg
      viewBox="0 0 240 360"
      className={className}
      role="img"
      aria-label={`Hand-painted bottle illustration, ${variant} pattern`}
    >
      {/* Glass body */}
      <path
        d="M90 60 L90 40 Q90 24 106 24 L134 24 Q150 24 150 40 L150 60 Q176 84 176 120 L176 320 Q176 336 160 336 L80 336 Q64 336 64 320 L64 120 Q64 84 90 60 Z"
        fill={p.wash}
        stroke="#16231F"
        strokeWidth="2"
      />
      {/* Neck ring */}
      <rect x="86" y="56" width="68" height="10" rx="3" fill="#16231F" opacity="0.15" />

      {/* Painted brush strokes — vary by variant */}
      {variant === 'lotus' && (
        <>
          <path d="M120 150 Q90 190 120 230 Q150 190 120 150 Z" fill={p.accent} opacity="0.9" />
          <path d="M120 170 Q104 195 120 220 Q136 195 120 170 Z" fill={p.accent2} opacity="0.85" />
          <circle cx="120" cy="150" r="7" fill={p.accent2} />
        </>
      )}
      {variant === 'peacock' && (
        <>
          <path
            d="M70 260 Q120 120 176 200"
            fill="none"
            stroke={p.accent}
            strokeWidth="10"
            strokeLinecap="round"
          />
          <circle cx="150" cy="160" r="16" fill={p.accent2} opacity="0.85" />
          <circle cx="150" cy="160" r="7" fill={p.accent} />
        </>
      )}
      {variant === 'sport' && (
        <>
          <rect x="64" y="180" width="112" height="14" fill={p.accent} opacity="0.85" />
          <rect x="64" y="210" width="112" height="6" fill={p.accent2} opacity="0.7" />
        </>
      )}
      {variant === 'giftset' && (
        <>
          <path d="M64 150 L176 150" stroke={p.accent} strokeWidth="10" />
          <path d="M120 90 L120 336" stroke={p.accent2} strokeWidth="10" />
          <circle cx="120" cy="150" r="14" fill={p.accent} />
        </>
      )}

      {/* Cap */}
      <rect x="94" y="6" width="52" height="20" rx="4" fill="#16231F" />
    </svg>
  );
}

export type { BottleVariant };
