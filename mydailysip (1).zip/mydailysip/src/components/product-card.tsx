import Link from 'next/link';
import { BottleIllustration, type BottleVariant } from '@/components/bottle-illustration';

export interface ProductCardData {
  slug: string;
  name: string;
  shortDescription: string;
  price: number;
  compareAtPrice?: number | null;
  capacityMl?: number | null;
  isHandPainted: boolean;
  illustration: BottleVariant;
}

function formatInr(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <Link
      href={`/products/${product.slug}`}
      className="group block overflow-hidden rounded-label border border-glass-100 bg-white transition-shadow hover:shadow-lg hover:shadow-glass-900/5"
    >
      <div className="relative flex aspect-[4/5] items-center justify-center bg-paper-dim">
        <BottleIllustration
          variant={product.illustration}
          className="h-4/5 w-auto transition-transform duration-500 ease-out group-hover:-translate-y-1 group-hover:scale-[1.03]"
        />
        {product.isHandPainted ? (
          <span className="absolute left-3 top-3 rounded-label bg-glass px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-paper">
            Hand-Painted
          </span>
        ) : (
          <span className="absolute left-3 top-3 rounded-label bg-glass-500 px-2 py-1 font-mono text-[10px] uppercase tracking-wide text-paper">
            BPA-Free
          </span>
        )}
      </div>

      <div className="space-y-2 p-5">
        <h3 className="font-display text-lg leading-snug text-ink">{product.name}</h3>
        <p className="line-clamp-2 text-sm text-ink/60">{product.shortDescription}</p>

        <div className="flex items-center justify-between pt-2">
          <div className="flex items-baseline gap-2 font-mono">
            <span className="text-base font-bold text-pigment">{formatInr(product.price)}</span>
            {product.compareAtPrice ? (
              <span className="text-xs text-ink/40 line-through">
                {formatInr(product.compareAtPrice)}
              </span>
            ) : null}
          </div>
          {product.capacityMl ? (
            <span className="font-mono text-xs text-ink/50">{product.capacityMl}ml</span>
          ) : null}
        </div>
      </div>
    </Link>
  );
}
