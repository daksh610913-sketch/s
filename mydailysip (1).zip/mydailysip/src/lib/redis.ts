import 'server-only';

/**
 * Unified Redis accessor.
 *
 * In production (Vercel), Upstash's REST client is used — it works over
 * plain HTTPS requests, which is what serverless functions need (no
 * long-lived TCP connections, no connection-pool exhaustion across
 * cold starts).
 *
 * In local development (docker-compose), a real Redis instance is
 * available on a TCP port, so ioredis is used instead — it's faster
 * for a long-running local Node process and doesn't require an
 * Upstash account just to run `npm run dev`.
 */

export interface RedisLike {
  get(key: string): Promise<string | null>;
  set(key: string, value: string, opts?: { ex?: number }): Promise<unknown>;
  del(key: string): Promise<unknown>;
  incr(key: string): Promise<number>;
  expire(key: string, seconds: number): Promise<unknown>;
}

let client: RedisLike | null = null;

export async function getRedis(): Promise<RedisLike> {
  if (client) return client;

  const hasUpstash = Boolean(
    process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN,
  );

  if (hasUpstash) {
    const { Redis } = await import('@upstash/redis');
    const upstash = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL!,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    });

    client = {
      get: (key) => upstash.get<string>(key),
      set: (key, value, opts) =>
        opts?.ex ? upstash.set(key, value, { ex: opts.ex }) : upstash.set(key, value),
      del: (key) => upstash.del(key),
      incr: (key) => upstash.incr(key),
      expire: (key, seconds) => upstash.expire(key, seconds),
    };
    return client;
  }

  // Local development fallback — docker-compose Redis over TCP.
  const { default: IORedis } = await import('ioredis');
  const ioredis = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379');

  client = {
    get: (key) => ioredis.get(key),
    set: (key, value, opts) =>
      opts?.ex ? ioredis.set(key, value, 'EX', opts.ex) : ioredis.set(key, value),
    del: (key) => ioredis.del(key),
    incr: (key) => ioredis.incr(key),
    expire: (key, seconds) => ioredis.expire(key, seconds),
  };
  return client;
}
