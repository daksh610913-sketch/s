import { PrismaClient } from '@prisma/client';

declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

const logLevels =
  process.env.NODE_ENV === 'development'
    ? (['query', 'error', 'warn'] as const)
    : (['error'] as const);

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: [...logLevels],
    datasources: {
      db: {
        url: process.env.DATABASE_URL,
      },
    },
  });

if (process.env.NODE_ENV !== 'production') {
  global.__prisma = prisma;
}

export default prisma;
