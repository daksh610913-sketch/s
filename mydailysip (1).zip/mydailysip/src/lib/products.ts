import 'server-only';
import { prisma } from '@/lib/prisma';
import type { ProductCardData } from '@/components/product-card';
import type { BottleVariant } from '@/components/bottle-illustration';

/**
 * Deterministically maps a product to one of the hand-drawn bottle
 * illustration variants until real product photography is uploaded to
 * Cloudinary. Based on product type + slug so the mapping is stable.
 */
function pickIllustration(type: string, slug: string): BottleVariant {
  if (type === 'GIFT_SET') return 'giftset';
  if (type === 'PLASTIC_BOTTLE') return 'sport';
  // Hand-painted glass: alternate between two motifs by slug parity.
  const charSum = slug.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return charSum % 2 === 0 ? 'lotus' : 'peacock';
}

export async function getFeaturedProducts(limit = 8): Promise<ProductCardData[]> {
  const products = await prisma.product.findMany({
    where: { status: 'PUBLISHED', deletedAt: null },
    orderBy: [{ soldCount: 'desc' }, { createdAt: 'desc' }],
    take: limit,
    select: {
      slug: true,
      name: true,
      shortDescription: true,
      basePrice: true,
      compareAtPrice: true,
      capacityMl: true,
      isHandPainted: true,
      type: true,
    },
  });

  return products.map((p) => ({
    slug: p.slug,
    name: p.name,
    shortDescription: p.shortDescription ?? '',
    price: Number(p.basePrice),
    compareAtPrice: p.compareAtPrice ? Number(p.compareAtPrice) : null,
    capacityMl: p.capacityMl,
    isHandPainted: p.isHandPainted,
    illustration: pickIllustration(p.type, p.slug),
  }));
}

export interface CategoryTileData {
  slug: string;
  name: string;
  description: string | null;
  productCount: number;
}

export async function getStorefrontCategories(): Promise<CategoryTileData[]> {
  const categories = await prisma.category.findMany({
    where: { isActive: true, deletedAt: null },
    orderBy: { sortOrder: 'asc' },
    select: {
      slug: true,
      name: true,
      description: true,
      _count: { select: { products: true } },
    },
  });

  return categories.map((c) => ({
    slug: c.slug,
    name: c.name,
    description: c.description,
    productCount: c._count.products,
  }));
}
